import java.io.*;
import java.util.*;

public class SimpleNotesApp {
    private static final String DIR = "notes";

    public static void main(String[] args) {
        new File(DIR).mkdirs();
        Scanner sc = new Scanner(System.in);

        while (true) {
            menu();
            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> writeNote(sc, "JavaFile1.txt");
                case "2" -> showNote("JavaFile1.txt");
                case "3" -> createNote2();
                case "4" -> copyContent("JavaFile1.txt", "JavaFile2.txt");
                case "5" -> analyzeNote(sc, "JavaFile1.txt");
                case "6" -> showNote("JavaFile2.txt");
                case "7" -> {
                    System.out.println("Goodbye!");
                    sc.close();
                    return;
                }
                default -> System.out.println("Invalid option.");
            }
        }
    }

    private static void menu() {
        System.out.print("""
                
                --- Note Utility ---
                1. Write JavaFile1.txt
                2. View JavaFile1.txt
                3. Create JavaFile2.txt
                4. Copy JavaFile1 ➝ JavaFile2
                5. Analyze JavaFile1.txt
                6. View JavaFile2.txt
                7. Exit
                Choose: """);
    }

    private static void writeNote(Scanner sc, String file) {
        System.out.println("Type note content. Type 'END' to finish:");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(new File(DIR, file)))) {
            String line;
            while (!(line = sc.nextLine()).equalsIgnoreCase("END")) {
                bw.write(line);
                bw.newLine();
            }
            System.out.println(file + " saved.");
        } catch (IOException e) {
            System.out.println("Write error: " + e.getMessage());
        }
    }

    private static void showNote(String file) {
        File f = new File(DIR, file);
        if (!f.exists()) {
            System.out.println("File not found.");
            return;
        }

        System.out.println("\n-- " + file + " Content --");
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null)
                System.out.println(line);
        } catch (IOException e) {
            System.out.println("Read error: " + e.getMessage());
        }
    }

    private static void createNote2() {
        String[] lines = {"This is the first line in this JavaFile2.txt file."};
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(new File(DIR, "JavaFile2.txt")))) {
            for (String l : lines) {
                bw.write(l);
                bw.newLine();
            }
            System.out.println("JavaFile2.txt created.");
        } catch (IOException e) {
            System.out.println("Creation failed: " + e.getMessage());
        }
    }

    private static void copyContent(String src, String dest) {
        File from = new File(DIR, src), to = new File(DIR, dest);
        if (!from.exists()) {
            System.out.println("Source file missing.");
            return;
        }

        try (
            BufferedReader br = new BufferedReader(new FileReader(from));
            BufferedWriter bw = new BufferedWriter(new FileWriter(to, true))
        ) {
            String line;
            while ((line = br.readLine()) != null) {
                bw.write(line);
                bw.newLine();
            }
            System.out.println("Copied from " + src + " to " + dest);
        } catch (IOException e) {
            System.out.println("Copy failed: " + e.getMessage());
        }

        showNote(dest);
    }

    private static void analyzeNote(Scanner sc, String file) {
        File f = new File(DIR, file);
        if (!f.exists()) {
            System.out.println("Analysis file missing.");
            return;
        }

        System.out.print("Enter word to search: ");
        String word = sc.nextLine().toLowerCase().trim();
        int lines = 0, words = 0, chars = 0, matches = 0, lineNo = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null) {
                lineNo++;
                lines++;
                chars += line.length();
                String[] tokens = line.split("\\s+");
                words += tokens.length;

                for (String t : tokens) {
                    String clean = t.toLowerCase().replaceAll("[^a-z0-9]", "");
                    if (clean.equals(word)) {
                        matches++;
                        System.out.println("'" + word + "' found on line " + lineNo);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Analyze error: " + e.getMessage());
            return;
        }

        System.out.printf("""
                
                --- Stats ---
                Characters: %d
                Words: %d
                Lines: %d
                '%s' Occurrences: %d
                """, chars, words, lines, word, matches);
    }
}
